<?php namespace App\SupportedApps\authentik;

class authentik extends \App\SupportedApps
{
}
