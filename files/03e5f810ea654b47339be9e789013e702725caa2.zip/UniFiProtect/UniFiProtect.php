<?php namespace App\SupportedApps\UniFiProtect;

class UniFiProtect extends \App\SupportedApps {

}