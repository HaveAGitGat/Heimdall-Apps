<?php namespace App\SupportedApps\OpenMapTiler;

class OpenMapTiler extends \App\SupportedApps
{
}
