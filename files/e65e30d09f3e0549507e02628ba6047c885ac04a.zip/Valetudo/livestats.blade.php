<ul class="livestats">
    <li>
        <span class="title">Last Session Time</span>
        <strong>{!! $last_session_time !!}m</strong>
    </li>
    <li>
        <span class="title">Last Session Area</span>
        <strong>{!! $last_session_area !!}m²</strong>
    </li>
</ul>