<ul class="livestats">
    <li>
        <span class="title">Aircraft</span>
        <strong>{!! $total !!}</strong>
    </li>
    <li>
        <span class="title">Positions</span>
        <strong>{!! $positions !!}</strong>
    </li>

</ul>
