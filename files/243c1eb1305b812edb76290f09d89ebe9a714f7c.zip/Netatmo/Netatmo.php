<?php namespace App\SupportedApps\Netatmo;

class Netatmo extends \App\SupportedApps
{
}
