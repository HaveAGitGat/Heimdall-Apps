<?php namespace App\SupportedApps\ArchiveBox;

class ArchiveBox extends \App\SupportedApps
{
}
