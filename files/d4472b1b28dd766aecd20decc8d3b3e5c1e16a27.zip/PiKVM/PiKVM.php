<?php namespace App\SupportedApps\PiKVM;

class PiKVM extends \App\SupportedApps
{
}
