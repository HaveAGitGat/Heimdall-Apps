<?php namespace App\SupportedApps\McMyAdmin;

class McMyAdmin extends \App\SupportedApps
{
}
