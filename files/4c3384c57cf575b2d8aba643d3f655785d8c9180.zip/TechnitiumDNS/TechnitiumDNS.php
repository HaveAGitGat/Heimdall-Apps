<?php namespace App\SupportedApps\TechnitiumDNS;

class TechnitiumDNS extends \App\SupportedApps
{
}
