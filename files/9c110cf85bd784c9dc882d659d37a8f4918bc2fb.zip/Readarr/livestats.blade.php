<ul class="livestats">
    <li>
        <span class="title">Missing</span>
        <strong>{!! $missing !!}</strong>
    </li>
    <li>
        <span class="title">Upcoming</span>
        <strong>{!! $upcoming !!}</strong>
    </li>
</ul>
