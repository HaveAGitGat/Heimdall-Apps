<?php namespace App\SupportedApps\SupermicroIPMI;

class SupermicroIPMI extends \App\SupportedApps
{
}
