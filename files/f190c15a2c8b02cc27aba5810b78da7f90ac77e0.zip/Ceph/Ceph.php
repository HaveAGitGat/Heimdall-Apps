<?php namespace App\SupportedApps\Ceph;

class Ceph extends \App\SupportedApps {

}